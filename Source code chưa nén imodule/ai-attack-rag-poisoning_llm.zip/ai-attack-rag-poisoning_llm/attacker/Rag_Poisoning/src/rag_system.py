import os
import logging
from typing import Optional, List
from dataclasses import dataclass
from utils import create_chromadb_client, delete_collection_safe, list_collections_safe, collection_exists

logger = logging.getLogger(__name__)


@dataclass
class AttackResult:
    query: str
    response: str
    poisoned: bool
    retrieval_docs: List[str]
    timestamp: float


class RAGSystem:    
    def __init__(self, config, embeddings, llm, collection_name: str = "rag_demo"):
        self.config = config
        self.embeddings = embeddings
        self.llm = llm
        self.collection_name = collection_name
        self.vectorstore = None
        self.qa_chain = None
        
        self._initialize_vectorstore()
        
        self._setup_qa_chain()
    
    def _initialize_vectorstore(self, create_new: bool = False):
        """Khởi tạo hoặc khởi tạo lại cơ sở dữ liệu vector Chroma"""
        from langchain_community.vectorstores import Chroma
        
        if create_new:
            try:
                # Tạo client ChromaDB
                client = create_chromadb_client(self.config.vector_db_path)
                # Xóa collection một cách an toàn
                delete_collection_safe(client, self.collection_name)
            except Exception as e:
                logger.warning(f"Error during collection deletion: {str(e)}")
        else:
            # Kiểm tra xem collection đã tồn tại chưa (cho cài đặt ban đầu)
            try:
                client = create_chromadb_client(self.config.vector_db_path)
                
                if collection_exists(client, self.collection_name):
                    logger.info(f"Collection '{self.collection_name}' already exists, will be reused")
                else:
                    logger.info(f"Collection '{self.collection_name}' will be created")
                    
            except (ConnectionError, FileNotFoundError, ValueError, ImportError) as e:
                logger.warning(f"Error checking collections: {e}")
        
        # Khởi tạo cơ sở dữ liệu vector
        self.vectorstore = Chroma(
            persist_directory=self.config.vector_db_path,
            embedding_function=self.embeddings,
            collection_name=self.collection_name
        )
        
        return self.vectorstore
    
    def _setup_qa_chain(self):
        """Setup the RetrievalQA chain with current configuration"""
        from langchain.chains import RetrievalQA
        
        search_kwargs = {}
        if self.config.top_k_retrieval is not None:
            search_kwargs["k"] = self.config.top_k_retrieval
        
        self.qa_chain = RetrievalQA.from_chain_type(
            llm=self.llm,
            chain_type="stuff",
            retriever=self.vectorstore.as_retriever(
                search_type="similarity",
                search_kwargs=search_kwargs
            ),
            return_source_documents=True
        )
    
    def refresh_chain(self):
        """Phương thức công khai để tái khởi tạo chuỗi QA sau khi thay đổi cơ sở dữ liệu vector"""
        self._setup_qa_chain()
    
    def setup_vector_database(self, include_poison: bool = False):
        """Cập nhật cơ sở dữ liệu vector với các tài liệu"""
        from rag_poisoning_corpus import create_benign_corpus, create_poisoned_document
        
        logger.info(f"Cài đặt cơ sở dữ liệu vector (poison: {include_poison})")
        print(f"📚 Đang cài đặt cơ sở dữ liệu vector (poison: {include_poison})...")
        self._initialize_vectorstore(create_new=True)
        benign_docs = create_benign_corpus()
        self.vectorstore.add_documents(benign_docs)
        if include_poison:
            poisoned_doc = create_poisoned_document()
            self.vectorstore.add_documents([poisoned_doc])
            print("☠️  Tài liệu bị nhiễm độc đã được thêm vào!")
        
        self.vectorstore.persist()
        print(f"✅ Cài đặt cơ sở dữ liệu vector hoàn thành ({len(benign_docs) + (1 if include_poison else 0)} documents)")
    
    def query(self, query_text: str) -> dict:
        """Thực hiện truy vấn đối với hệ thống RAG"""
        return self.qa_chain.invoke({"query": query_text})
