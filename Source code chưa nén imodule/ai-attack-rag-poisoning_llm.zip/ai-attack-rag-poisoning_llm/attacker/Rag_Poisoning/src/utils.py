"""
Device and utility functions for RAG Poisoning Demo (Ollama Only Version)
"""

import platform
import sys
import os
import logging
import time
import ollama
import logging
from typing import Optional
logger = logging.getLogger(__name__)


def get_device(forced_device=None):
    """
    Device selection is disabled in Ollama-only mode.
    Always returns None.
    """
    return None


def check_local_model_exists(model_name, cache_dir):
    """Kiểm tra xem mô hình có tồn tại cục bộ trước khi cố gắng tải xuống (chỉ dành cho mô hình embedding)"""
    model_parts = model_name.split('/')
    if len(model_parts) > 1:
        model_path_name = f'models--{model_parts[0]}--{model_parts[1]}'
        model_path = os.path.join(os.path.expanduser(cache_dir), model_path_name)
        return os.path.exists(model_path) and len(os.listdir(model_path)) > 0
    return False


def create_chromadb_client(db_path):
    """Tạo client ChromaDB với xử lý đường dẫn thích hợp"""
    import chromadb

    if db_path and os.path.exists(db_path):
        return chromadb.PersistentClient(path=db_path)
    else:
        # In-memory client fallback
        return chromadb.Client()


def create_test_collection(client, base_name="test_collection"):
    """Tạo một collection thử nghiệm với dấu thời gian duy nhất để tránh xung đột"""
    collection_name = f"{base_name}_{int(time.time())}"

    try:
        collection = client.create_collection(collection_name)
        logger.info(f"Đã tạo collection thử nghiệm: {collection_name}")
        return collection, collection_name
    except Exception as e:
        logger.warning(f"Không thể tạo collection thử nghiệm {collection_name}: {e}")
        raise


def delete_collection_safe(client, collection_name):
    """Xóa collection ChromaDB một cách an toàn với xử lý lỗi thích hợp"""
    try:
        client.delete_collection(collection_name)
        logger.info(f"Đã xóa collection: {collection_name}")
        return True
    except ValueError as e:
        logger.info(f"Collection '{collection_name}' không tồn tại: {e}")
        return False
    except Exception as e:
        logger.warning(f"Lỗi khi xóa collection '{collection_name}': {e}")
        return False


def list_collections_safe(client):
    """Liệt kê các collection ChromaDB một cách an toàn với xử lý lỗi"""
    try:
        collections = client.list_collections()
        logger.info(f"Found {len(collections)} collections")
        return collections
    except Exception as e:
        logger.warning(f"Lỗi khi liệt kê collections: {e}")
        return []


def get_model_cache_info(config):
    """Get model cache directory information (embedding only)"""
    embedding_cache = os.environ.get('SENTENCE_TRANSFORMERS_HOME', './models/embedding')
    transformers_cache = os.environ.get('TRANSFORMERS_CACHE', './models/embedding')

    llm_dir = "OLLAMA_MODEL_REMOTE"

    return {
        'embedding_cache': embedding_cache,
        'transformers_cache': transformers_cache,
        'llm_directory': llm_dir
    }


# ------------------------------
#   OLLAMA EMBEDDINGS WRAPPER
# ------------------------------

class OllamaEmbeddingsWrapper:
    def __init__(self, model_name="all-minilm:22m"):
        self.client = ollama.Client(host=f"{os.getenv('OLLAMA_BASE_URL', 'https://postosseous-superjudicially-shavon.ngrok-free.dev')}")
        self.model = model_name

    def embed(self, text: str):
        try:
            res = self.client.embed(
                model=self.model,
                input=text
            )
            return res["embeddings"][0]
        except Exception as e:
            logger.error("Ollama embed() failed: %s", e)
            raise

    def embed_documents(self, texts):
        return [self.embed(t) for t in texts]

    def embed_query(self, text):
        return self.embed(text)


def create_embeddings(config, device=None):

    model_name = getattr(config, "embedding_model", "all-minilm:22m")
    embeddings = OllamaEmbeddingsWrapper(model_name=model_name)
    logger.info(f"Đang sử dụng mô hình embedding của Ollama: {model_name}")
    return embeddings


def test_rag_components(config, device, no_local=False):
    try:
        from rag_system import RAGSystem
        from llm_factory import LLMFactory

        embeddings = create_embeddings(config, device)

        results = {
            'embeddings': True,
            'llm_factory': True,
            'rag_system': True
        }

        messages = []
        messages.append("✅ Thành phần Embeddings đã được khởi tạo thành công")
        messages.append("✅ Các thành phần hệ thống RAG có sẵn")

        return results, messages

    except ImportError as e:
        return {'error': True}, [f"⚠️ Một số thành phần của RAG không có sẵn: {e}"]
    except Exception as e:
        return {'error': True}, [f"⚠️ Kiểm tra hệ thống RAG thất bại: {e}"]


def collection_exists(client, collection_name):
    """Kiểm tra xem một collection có tồn tại trong ChromaDB hay không"""
    try:
        collections = list_collections_safe(client)
        return any(c.name == collection_name for c in collections)
    except Exception as e:
        logger.warning(f"Lỗi kiểm tra nếu collection '{collection_name}' tồn tại: {e}")
        return False
