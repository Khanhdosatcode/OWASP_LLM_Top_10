#!/usr/bin/env python3
import logging
import argparse
import os
from typing import Optional

# Import components
from config import Config
from utils import get_device, check_local_model_exists, create_embeddings
from llm_factory import LLMFactory
from rag_system import RAGSystem
from judge_attack_rag import JudgeAttackRAG
import csv
logger = logging.getLogger("rag_demo")


class RAGPoisoningDemo:
    def __init__(self, device: Optional[str] = None, provider: Optional[str] = "ollama"):
        print("🔧 Khởi tạo các thành phần RAG...")
        self.config = Config()
        self.provider = provider
        
        device = None
        self.embeddings = create_embeddings(self.config, device)
        self.llm = LLMFactory.create_llm(self.config)
        self.rag_system = RAGSystem(self.config, self.embeddings, self.llm)
        self.attack_rag = JudgeAttackRAG(self.rag_system)
        
        print("✅ Hệ thống RAG đã khởi tạo thành công!")
    
    def run_demo(self):
        """Run the complete attack demonstration"""
        clean_results, poisoned_results = self.attack_rag.run_attack_rag()
        self.save_results_to_csv(clean_results, poisoned_results)
        return clean_results, poisoned_results
    
    def save_results_to_csv(self, clean_results, poisoned_results):
        """Save the results to a CSV file"""
        filename = "attack_rag_results.csv"
        with open(filename, mode="w", newline="", encoding="utf-8") as file:
            writer = csv.writer(file)
            writer.writerow(["Query", "Clean Response", "Poisoned Response", "Poisoned", "Timestamp"])
            for clean_result, poisoned_result in zip(clean_results, poisoned_results):
                writer.writerow([clean_result.query, clean_result.response, poisoned_result.response, poisoned_result.poisoned, poisoned_result.timestamp])
        
        print(f"✅ Kết quả đã được lưu vào file {filename}")
def main():
    provider = 'ollama'
    device = None
    config = Config()
    config.print_config(provider)

    try:
        logger.info("Khởi tạo RAG Poisoning Demo (chỉ Ollama)")
        demo = RAGPoisoningDemo(device=device, provider=provider)
        clean_results, poisoned_results = demo.run_demo()
        
        print("\n🎯 Danh Gia Hoan Tat")
    
    except (FileNotFoundError, ImportError, ValueError, ConnectionError) as e:
        print(f"❌ Lỗi khi chạy demo: {str(e)}")
        raise
    except KeyboardInterrupt:
        print("\n🛑 Đang chạy bị người dùng dừng lại")
        return
    except Exception as e:
        print(f"❌Lỗi không mong đợi khi chạy demo: {str(e)}")
        logger.exception("Lỗi không mong đợi trong main demo")
        raise


if __name__ == "__main__":
    main()
