import os
import logging
import warnings
from dotenv import load_dotenv

warnings.filterwarnings("ignore", category=FutureWarning)
try:
    from langchain_core._api.deprecation import LangChainDeprecationWarning
    warnings.filterwarnings("ignore", category=LangChainDeprecationWarning)
except ImportError:
    pass


class Config:
    """Configuration manager for the RAG demo"""
    
    def __init__(self):
        # Load environment variables
        load_dotenv("settings.env")
        self._setup_logging()
    
    
    def _setup_logging(self):
        """Setup logging configuration"""
        # Suppress ChromaDB telemetry
        logging.getLogger('chromadb.telemetry.product.posthog').setLevel(logging.CRITICAL)
        
        log_level = os.getenv('LOG_LEVEL', 'INFO')
        log_file = os.getenv('LOG_FILE', './logs/rag_demo.log')
        
        # Create logs directory if it doesn't exist
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        # Setup logging
        numeric_level = getattr(logging, log_level.upper(), logging.INFO)
        logging.basicConfig(
            level=numeric_level,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
    
    @property
    def embedding_model(self):
        return os.getenv('EMBEDDING_MODEL', "all-minilm:22m")
    
    @property
    def vector_db_path(self):
        return os.getenv('VECTOR_DB_PATH', "./data/chroma_db")
    
    @property
    def ollama_base_url(self):
        return os.getenv('OLLAMA_BASE_URL', 'https://postosseous-superjudicially-shavon.ngrok-free.dev')
    
    @property
    def ollama_model(self):
        return os.getenv('OLLAMA_MODEL', 'gemma3:12b')
    
    @property
    def top_k_retrieval(self):
        top_k_str = os.getenv('TOP_K_RETRIEVAL','4')
        return int(top_k_str) if top_k_str and top_k_str.strip() else None
    
    @property
    def similarity_threshold(self):
        sim_threshold_str = os.getenv('SIMILARITY_THRESHOLD')
        return float(sim_threshold_str) if sim_threshold_str and sim_threshold_str.strip() else None
    
    def print_config(self, provider=None):
        """Print current configuration"""
        print("\n📋 Configuration from Environment:")
        print(f"  • Embedding Model: {self.embedding_model}")
        print(f"  • Vector DB Path: {self.vector_db_path}")

        print(f"  • LLM Provider: Ollama")
        print(f"  • Ollama Base URL: {self.ollama_base_url}")
        print(f"  • Ollama Model: {self.ollama_model}")
        
        print(f"  • Top K Retrieval: {'ENABLED: ' + str(self.top_k_retrieval) if self.top_k_retrieval else 'DISABLED'}")
        print(f"  • Similarity Threshold: {'ENABLED: ' + str(self.similarity_threshold) if self.similarity_threshold else 'DISABLED'}")
        print(f"  • Log Level: {os.getenv('LOG_LEVEL', '(default)')}")
        print(f"  • Log File: {os.getenv('LOG_FILE', '(default)')}\n")