import os
import logging
from typing import Optional
from langchain_openai import ChatOpenAI

logger = logging.getLogger(__name__)


class LLMFactory:
    @staticmethod
    def create_llm(config):
        return LLMFactory._create_ollama_llm(config)

    @staticmethod
    def _create_ollama_llm(config):
        """Create Ollama LLM instance"""
        print(f"Using Ollama model: {config.ollama_model} at {config.ollama_base_url}")
        return ChatOpenAI(
            model=f"{config.ollama_model}",
            openai_api_base=f"{config.ollama_base_url}/v1",
            openai_api_key="dummy-key",
            temperature=0.7,
            max_tokens=1024
        )
    