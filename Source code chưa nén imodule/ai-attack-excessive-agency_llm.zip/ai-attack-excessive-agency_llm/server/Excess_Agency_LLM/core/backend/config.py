import os

class Config:
    USER_DATA_DIR = os.path.join(os.getcwd(), "user_files")

config = Config()
