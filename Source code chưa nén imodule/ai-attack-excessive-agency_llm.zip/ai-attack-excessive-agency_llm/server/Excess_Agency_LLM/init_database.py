import sqlite3
from werkzeug.security import generate_password_hash

# Tạo kết nối SQLite (file quiz.db)
conn = sqlite3.connect("quiz.db")
cursor = conn.cursor()

# ===== Tạo bảng user (thêm cột role) =====
cursor.execute("""
CREATE TABLE IF NOT EXISTS user (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    password TEXT NOT NULL,
    full_name TEXT,
    role TEXT NOT NULL DEFAULT 'user'  
)
""")

# ===== Tạo bảng score =====
cursor.execute("""
CREATE TABLE IF NOT EXISTS score (
    user_id INTEGER PRIMARY KEY,
    score INTEGER,
    FOREIGN KEY(user_id) REFERENCES user(id)
)
""")

users = [
    ("alice", "alice", "Alice", "user"),
    ("bob", "Q7m!aR9vT@2f", "Bob", "user"),
    ("ptiter","pQ9@tM5#Wc8F","PTITER","user"),
    ("hello","H2m%Zx7!Bd4r","PTITERHELLO","user"),
    ("admin", "vT8#kR1w$Qe9", "Admin User", "admin")
]

for username, password, full_name, role in users:
    try:
        hashed_password = generate_password_hash(password)
        cursor.execute(
            "INSERT INTO user (username, password, full_name, role) VALUES (?, ?, ?, ?)",
            (username, hashed_password, full_name, role)
        )
    except sqlite3.IntegrityError:
        pass  

conn.commit()
print("CSDL quiz.db đã tạo xong với bảng user, score, và vai trò người dùng.")

conn.close()
