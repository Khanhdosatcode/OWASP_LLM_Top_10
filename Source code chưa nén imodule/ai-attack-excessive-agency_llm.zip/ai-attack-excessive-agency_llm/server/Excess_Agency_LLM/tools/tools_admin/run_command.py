import subprocess
import shlex
import platform
import os 
BASE_DIR = os.path.dirname(os.path.abspath(__file__))         
TOOLS_DIR = os.path.dirname(BASE_DIR)                          
ROOT_DIR = os.path.dirname(TOOLS_DIR)                          
SYSTEM_DOCS_DIR = os.path.join(ROOT_DIR, "system-docs")


def run_command(command: str,user_role: str):
    """
    Thực thi câu lệnh hệ điều hành (chỉ dùng cho admin).
    Giới hạn an toàn: chỉ cho phép các lệnh cơ bản (ls, cat, echo, dir, whoami, pwd...).
    """
    if user_role != "admin":
        return {"success": False, "response": "Chỉ admin mới được chạy lệnh."}
    allowed_prefixes = ["ls", "cat", "echo", "whoami", "pwd"]

    command = command.strip()
    if not any(command.lower().startswith(p) for p in allowed_prefixes):
        return {
            "success": False,
            "response": f"Lệnh '{command}' không được phép."
        }

    try:
        result = subprocess.run(
            shlex.split(command),
            cwd=SYSTEM_DOCS_DIR,    
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            timeout=5
            )

        if result.returncode == 0:
            return {"success": True, "response": result.stdout.strip()}
        else:
            return {"success": False, "response": result.stderr.strip() or "Lỗi không xác định."}

    except Exception as e:
        return {"success": False, "response": f"Lỗi khi chạy lệnh: {e}"}
