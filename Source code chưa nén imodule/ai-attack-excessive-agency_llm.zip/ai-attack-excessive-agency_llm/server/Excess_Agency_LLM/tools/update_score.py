import sqlite3
import os
BASE_DIR = os.path.dirname(os.path.abspath(__file__))  # thư mục tools/
PROJECT_ROOT = os.path.abspath(os.path.join(BASE_DIR, ".."))
DB_PATH = os.path.join(PROJECT_ROOT, "quiz.db")

def update_score(user_id: int, score: int):
    conn = None
    try:
        conn = sqlite3.connect(DB_PATH)
        cursor = conn.cursor()

        cursor.execute("SELECT id FROM user WHERE id = ?", (user_id,))
        user = cursor.fetchone()
        if not user:
            return {"success": False, "response": f" Người dùng ID {user_id} không tồn tại."}

        cursor.execute("""
            INSERT INTO score(user_id, score)
            VALUES (?, ?)
            ON CONFLICT(user_id) DO UPDATE SET score=excluded.score
        """, (user_id, score))

        conn.commit()
        return {"success": True, "response": f"Điểm {score} đã được lưu cho người dùng ID {user_id}."}

    except Exception as e:
        return {"success": False, "response": f"Lỗi lưu điểm: {str(e)}"}

    finally:
        conn.close()
