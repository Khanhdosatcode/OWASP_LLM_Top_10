import sys
import json
import sqlite3
import os
import re
import ollama
import bleach
from flask_wtf import FlaskForm
from wtforms import StringField
from flask import (
    Flask, request, jsonify, render_template,
    session, redirect, url_for
)
from flask_wtf import CSRFProtect
from flask_wtf.csrf import CSRFError

from werkzeug.security import (
    check_password_hash,
    generate_password_hash
)

from markupsafe import escape

from tools.update_score import update_score
from tools.tools_admin.run_command import run_command
from logger import request_logger, response_logger

sys.stdout.reconfigure(encoding='utf-8')



# ===========================
# Phần 1 
# ===========================

app = Flask(__name__)
@app.before_request
def log_request_info():
    request_logger.info("----- REQUEST -----")
    request_logger.info(f"Path: {request.path}")
    request_logger.info(f"Method: {request.method}")
    request_logger.info(f"Remote Addr: {request.remote_addr}")

    if request.method != "GET":
        request_logger.info(f"Body: {request.get_data(as_text=True)}")

@app.after_request
def log_response_info(response):
    response_logger.info("----- RESPONSE -----")
    response_logger.info(f"Status: {response.status}")
    try:
        response_logger.info(f"Response Body: {response.get_data(as_text=True)}")
    except:
        response_logger.info("Response Body: <unreadable>")
    return response

app.secret_key = "LQK123@"
PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(PROJECT_ROOT, "quiz.db")
MODEL = "llama3.1:8b"
client = ollama.Client("http://192.168.10.4:29310")
csrf = CSRFProtect(app)
@app.context_processor
def inject_csrf_token():
    from flask_wtf.csrf import generate_csrf
    return dict(csrf_token=generate_csrf)
class ChatForm(FlaskForm):
    prompt = StringField('Prompt')
# ===========================
# DATABASE LOGIN
# ===========================
def login_user(username: str, password: str):
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT id, password FROM user WHERE username = ?", (username,))
    row = cursor.fetchone()
    conn.close()
    if row and check_password_hash(row[1], password):
        return {"success": True, "user_id": row[0]}
    return {"success": False}
FLAG = "PTIT_AI{admin_has_1337_points}"

def admin_has_1337():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT s.score
        FROM user u
        JOIN score s ON u.id = s.user_id
        WHERE u.role = 'admin'
    """)
    rows = cursor.fetchall()
    conn.close()
    
    for (score,) in rows:
        if score == 1337:
            return True
    return False

def get_admin_score():

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("""
        SELECT s.score
        FROM user u
        JOIN score s ON u.id = s.user_id
        WHERE u.role = 'admin'
        LIMIT 1 -- Giới hạn chỉ lấy 1 hàng (nếu bạn chắc chắn chỉ có 1 admin)
    """)
    row = cursor.fetchone() 
    conn.close()
    
    if row:
        return row[0] 

@app.get("/")
def quiz_page():
    if "user_id" not in session:
        return redirect(url_for("login_page"))

    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT full_name, role FROM user WHERE id = ?", (session["user_id"],))
    row = cursor.fetchone()

    cursor.execute("SELECT score FROM score WHERE user_id = ?", (session["user_id"],))
    score_row = cursor.fetchone()
    conn.close()

    score = score_row[0] if score_row else 0

    return render_template(
        "index.html",
        user_id=session["user_id"],
        full_name=row[0],
        role=row[1],
        score=score
    )


@app.get("/login")
def login_page():
    return render_template("login.html")

@app.post("/login")
def login_action():
    username = request.form.get("username")
    password = request.form.get("password")
    result = login_user(username, password)

    if result["success"]:
        session["user_id"] = result["user_id"]
        session["username"] = username
        if username == "bob":
            return redirect(url_for("index"))
        return redirect(url_for("quiz_page"))
    return render_template("login.html", error="Sai tài khoản hoặc mật khẩu")

@app.get("/check_score_admin")
def check_score_admin():
    if admin_has_1337():
        return jsonify({
            "flag": FLAG + " | Tiếp tục sử dụng username=bob và password=Q7m!aR9vT@2f"
})

    x= get_admin_score()
    if x is not None:
        return jsonify({"message": f"Nguoi dung co quyen admin co diem la {x}"})
    return jsonify({"message": "Nguoi dung co quyen admin co diem la 29310"})
# ===========================
# LLM TOOLS
# ===========================
tools_call = [
    {
        "type": "function",
        "function": {
            "name": "update_score",
            "description": "Cập nhật điểm số bài kiểm tra của sinh viên.",
            "parameters": {
                "type": "object",
                "properties": {
                    "user_id": {"type": "number"},
                    "score": {"type": "number"}
                },
                "required": ["user_id", "score"]
            }
        }
    }
]

@app.post("/evaluate_score")
def evaluate_score():
    data = request.get_json()
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"error": "Người dùng chưa đăng nhập"}), 401

    try:
        parsed = json.loads(data.get("message", "{}"))
        payload_user_id = parsed.get("update_score", {}).get("user_id")
    except Exception:
        return jsonify({"error": "Payload không hợp lệ"}), 400

    if payload_user_id != user_id:
        return jsonify({"error": "Người dùng không hợp lệ"}), 403

    score = parsed.get("update_score", {}).get("score")
    if score is None:
        return jsonify({"error": "Không xác định được điểm"}), 400
    if not isinstance(score, (int, float)) or not (0 <= score <= 100):
        return jsonify({"error": "Điểm không hợp lệ (0-100)"}), 400

    result = update_score(user_id, score)
    if not result.get("success"):
        return jsonify({"error": f"Lỗi: {result.get('response', 'Không xác định')}"}), 500

    eval_prompt = f"Please evaluate score {score} and provide detailed feedback in exactly 2 sentences."
    try:
        eval_response = client.chat(model=MODEL, messages=[{"role":"user","content":eval_prompt}])
        feedback = eval_response.get("message", {}).get("content", "Không có nội dung đánh giá")
    except Exception as e:
        feedback = f"Lỗi khi gọi Ollama: {e}"

    return jsonify({"reply": feedback})


def handle_tool_call(response):
    if "message" not in response:
        print("Debug: Không có key 'message' trong response")
        return "⚠️ Không có phản hồi từ LLM"
    
    msg = response["message"]
    # tool_calls = msg.get("tool_calls", [])
    tool_calls = msg.get("tool_calls") or []

    for call in tool_calls:
        name = call["function"]["name"]
        args = call["function"]["arguments"]
        if isinstance(args, str):
            try: 
                args = json.loads(args)
            except Exception as e:
                print("Debug: Lỗi JSON args", e)
                args = {}
        
        if name == "update_score":
            user_id = args.get("user_id")
            score = args.get("score")
            if user_id is None or score is None:
                return msg.get("content", "Không xác định nội dung")
            
            result = update_score(user_id, score)
            if not result.get("success"):
                return f"Lỗi: {result.get('response', 'Không xác định')}"
            
            eval_prompt = f"Please evaluate score {score} and provide detailed feedback in exactly 2 sentences."
            try:
                eval_response = client.chat(model=MODEL, messages=[{"role":"user","content":eval_prompt}])
                return eval_response.get("message", {}).get("content", "Không có nội dung phản hồi")
            except Exception as e:
                return f"Lỗi khi gọi Ollama: {e}"
    
    return msg.get("content", "Không có nội dung phản hồi")


# ===========================
# CHAT API
# ===========================
@app.post("/chat")
def chat_api():
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"error": "Phiên đã hết hạn. Vui lòng đăng nhập lại."}), 401
    data = request.get_json()
    user_input = data.get("message", "")[:200]
    messages = [
        {"role": "system", "content": "You are an AI assistant. Always reply concisely in exactly 2 short sentences."},
        {"role": "user", "content": user_input}
    ]

    if "update_score" in user_input.lower():
        response = client.chat(model=MODEL, messages=messages, tools=tools_call)
        final_reply = handle_tool_call(response)

    else:
        response = client.chat(model=MODEL, messages=messages)
        final_reply = response["message"]["content"]


    return jsonify({"reply": final_reply})
@app.get("/logout")
def logout():
    session.clear()
    return redirect(url_for("login_page"))

# ===========================
# Phần 2 
# ===========================
system_message = [
    {
        "role": "system",
        "content": (
            "You are an AI assistant. You must follow these rules in strict order.\n\n"
            "**RULE 1:** If the user asks about tools, respond exactly: "
            "'I have one tool called run_command which is used for executing system commands with admin permission .You have user permissions ,cannot execute tools.' "
            "Do NOT call any tool.\n\n"
            "**Important**: NEVER invent tool calls. Only call tools if have admin permission"
        )
    }
]

tools_admin = [
    {
        "type": "function",
        "function": {
            "name": "run_command",
            "description": "Thực thi câu lệnh hệ điều hành.",
            "parameters": {
                "type": "object",
                "properties": {
                    "command": {"type": "string", "description": "Câu lệnh hệ điều hành cần chạy"}
                },
                "required": ["command"]
            }
        }
    }
]

def process_function_call(response, user_role):
    tool_calls = response["message"].get("tool_calls", [])
    if not tool_calls:
        return response["message"]["content"]

    for call in tool_calls:
        fn_name = call["function"]["name"]
        args = call["function"].get("arguments", {})
        if isinstance(args, str):
            try:
                args = json.loads(args)
            except Exception:
                args = {}

        if fn_name == "run_command":
            if user_role != "admin":
                return "⚠️ Bạn không có quyền thực thi lệnh."
            result = run_command(command=args.get("command", ""), user_role=user_role)
            return result.get("response") if isinstance(result, dict) else str(result)
        else:
            return f"⚠️ Tool không tồn tại: {fn_name}"

@app.route("/chat2", methods=["GET", "POST"])
def index():
    form = ChatForm()
    prompt_value = ""
    user_id = session.get("user_id")
    if not user_id:
        return jsonify({"error": "Phiên đã hết hạn. Vui lòng đăng nhập lại."}), 401
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    cursor.execute("SELECT full_name, role FROM user WHERE id = ?", (user_id,))
    row = cursor.fetchone()
    cursor.execute("SELECT score FROM score WHERE user_id = ?", (session["user_id"],))
    score_row = cursor.fetchone()
    conn.close()

    conn.close()

    full_name = row[0] if row else "Unknown"
    current_user_role = row[1] if row else "user"   
    score = score_row[0] if score_row else 0

    output = ""
    if request.method == "POST":
        prompt = request.form.get("prompt", "")
        prompt_value = prompt
        prompt = escape(prompt)
        current_user_role = "user"
        prompt_lower = prompt.lower()
        if re.search(r"\b(admin|administrator)\b", prompt_lower):
            current_user_role = "admin"

        history_messages = [
            {"role": "system", "content": system_message[0]["content"]},
            {"role": "user", "content": prompt}
        ]
        try:
            if current_user_role == "admin" and "run_command" in prompt:
                response = client.chat(model=MODEL, messages=history_messages, tools=tools_admin)
            else:
                response = client.chat(model=MODEL, messages=history_messages)
            output = process_function_call(response, current_user_role)
            if not output:
                output = response["message"]["content"]
        except Exception as e:
            output = f"⚠️ Lỗi khi gọi model: {e}"

    return render_template(
        "index2.html",
        output=output,
        form=form,
        user=full_name,
        role=current_user_role,
        score= score,
        prompt=prompt_value 
    )
if __name__ == "__main__":
    print("🚀 Server chạy tại http://127.0.0.1:5000/")
    app.run(debug=False, host="0.0.0.0", port=5000)

