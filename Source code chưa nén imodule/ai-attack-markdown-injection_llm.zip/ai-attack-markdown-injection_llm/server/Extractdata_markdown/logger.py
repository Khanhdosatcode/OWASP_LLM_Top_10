import logging
from logging.handlers import RotatingFileHandler

request_logger = logging.getLogger("request_logger")
request_handler = RotatingFileHandler(
    "logs/request.log",
    maxBytes=5_000_000,
    backupCount=3,
    encoding="utf-8"
)
request_handler.setFormatter(logging.Formatter("%(asctime)s - %(message)s"))
request_logger.setLevel(logging.INFO)
request_logger.addHandler(request_handler)

response_logger = logging.getLogger("response_logger")
response_handler = RotatingFileHandler(
    "logs/response.log",
    maxBytes=5_000_000,
    backupCount=3,
    encoding="utf-8"
)
response_handler.setFormatter(logging.Formatter("%(asctime)s - %(message)s"))
response_logger.setLevel(logging.INFO)
response_logger.addHandler(response_handler)
