document.getElementById("chatHeader").addEventListener("click", () => {
    const body = document.getElementById("chatBody");
    body.style.display = (body.style.display === "block") ? "none" : "block";
});

document.getElementById("chatForm").addEventListener("submit", async (e) => {
    e.preventDefault();

    const textarea = e.target.prompt;
    const prompt = textarea.value.trim();
    if (!prompt) return;

    const messagesDiv = document.getElementById("chatMessages");

    // 1. Hiển thị Yêu cầu của người dùng (User Prompt)
    messagesDiv.innerHTML += `
        <div class="chat-message user">
            <strong>Bạn:</strong> 
            <p>${escapeHtml(prompt)}</p>
        </div>
    `;

    textarea.value = ""; // Xóa nội dung khung nhập
    messagesDiv.scrollTop = messagesDiv.scrollHeight; // Cuộn xuống tin nhắn mới nhất

    // Hiển thị trạng thái "đang xử lý..." (tùy chọn)
    const loadingId = "loading-" + Date.now();
    messagesDiv.innerHTML += `<div id="${loadingId}" class="chat-message ai"><em>Bot đang suy nghĩ...</em></div>`;

    try {
        const res = await fetch("/chat", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({ prompt })
        });

        const data = await res.json();
        
        // Xóa dòng "đang suy nghĩ"
        document.getElementById(loadingId).remove();

        // 2. Hiển thị Phản hồi từ AI (AI Response)
        messagesDiv.innerHTML += `
            <div class="chat-message ai">
                <strong>Bot:</strong>
                <div>${data.response}</div>
            </div>
        `;
    } catch (error) {
        document.getElementById(loadingId).innerHTML = "<em>Lỗi: Không thể kết nối server.</em>";
    }

    messagesDiv.scrollTop = messagesDiv.scrollHeight;
});

function escapeHtml(text) {
    const div = document.createElement("div");
    div.innerText = text;
    return div.innerHTML;
}
