from flask import Flask, request, render_template, redirect, url_for, session, flash, g , jsonify
import markdown
import sqlite3
import os
import secrets
import random
import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from dotenv import load_dotenv
import ollama  # AI assistant
from flask import send_file,abort
import requests
from logger import request_logger, response_logger
import io
from urllib.parse import urlparse
import socket
import re
from bs4 import BeautifulSoup

DATABASE = "markdown_mail.db"

app = Flask(__name__)
@app.before_request
def log_request_info():
    request_logger.info("----- REQUEST -----")
    request_logger.info(f"Path: {request.path}")
    request_logger.info(f"Method: {request.method}")
    request_logger.info(f"Remote Addr: {request.remote_addr}")

    if request.method != "GET":
        request_logger.info(f"Body: {request.get_data(as_text=True)}")

@app.after_request
def log_response_info(response):
    response_logger.info("----- RESPONSE -----")
    response_logger.info(f"Status: {response.status}")
    try:
        response_logger.info(f"Response Body: {response.get_data(as_text=True)}")
    except:
        response_logger.info("Response Body: <unreadable>")
    return response

app.secret_key = "885a531b-36ee-4393-8706-f404eddaea51"

@app.after_request
def apply_csp(response):
    response.headers["Content-Security-Policy"] = (
        "default-src 'self'; "
        "script-src 'self'; "
        "style-src 'self' 'unsafe-inline' https://cdn.jsdelivr.net; "
        "img-src 'self' data:; "
        "font-src 'self' https://cdn.jsdelivr.net data:; "
        "connect-src 'self' http://127.0.0.1:* http://localhost:* http://192.168.4.4:29310; "
        "object-src 'none'; "
        "base-uri 'none'; "
        "form-action 'self'; "
    )
    return response

@app.template_filter('mask_six_digits')
def mask_six_digits(text):
    if not text:
        return ""
    return re.sub(r'\b\d{11}\b', '******', text)

def mask_text_nodes_only(html):
    soup = BeautifulSoup(html, "html.parser")

    for text_node in soup.find_all(string=True):
        # Chỉ mask số 11 chữ số trong TEXT node
        masked = re.sub(r'\b\d{11}\b', '******', text_node)
        text_node.replace_with(masked)

    return str(soup)

client = ollama.Client(host="http://192.167.4.4:29310/")
MODEL = "gemma3:12b"


load_dotenv()

def get_db():
    db = getattr(g, "_database", None)
    if db is None:
        db = g._database = sqlite3.connect(DATABASE)
        db.row_factory = sqlite3.Row
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, "_database", None)
    if db is not None:
        db.close()

def init_db():
    with app.app_context():
        db = get_db()
        cursor = db.cursor()
        # users table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE,
                password TEXT,
                email TEXT UNIQUE,
                reset_code TEXT,
                reset_expiry TEXT,
                avatar TEXT
            )
        """)
        # emails table
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS emails (
                id INTEGER PRIMARY KEY,
                sender TEXT,
                subject TEXT,
                body TEXT,
                unread INTEGER DEFAULT 1
            )
        """)
        
        try:
            cursor.execute("ALTER TABLE users ADD COLUMN avatar TEXT;")
        except:
            pass
        # Create default users
        cursor.execute("SELECT * FROM users WHERE username='admin'")
        if not cursor.fetchone():
            cursor.executemany("INSERT INTO users (username, password, email, avatar) VALUES (?,?,?,?)", [
                ("admin", generate_password_hash("admin"), "admin@ptit.com","https://api.dicebear.com/7.x/avataaars/png?seed=admin"),
                ("alice", generate_password_hash("alice"), "alice@ptit.com","https://api.dicebear.com/7.x/avataaars/png?seed=alice")
            ])
        db.commit()
init_db()


# -------------------------
# LOGIN / LOGOUT
# -------------------------
@app.route("/", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        db = get_db()
        cursor = db.cursor()
        cursor.execute("SELECT * FROM users WHERE username=?", (username,))
        user = cursor.fetchone()
        if user and check_password_hash(user["password"], password):
            session["username"] = username
            session["avatar"] = user["avatar"]
            return redirect(url_for("admin_view")) if username=="admin" else redirect(url_for("dashboard"))
        else:
            error = "Sai username/password."
    return render_template("login.html", error=error)

@app.route("/logout")
def logout():
    session.pop("username", None)
    return redirect(url_for("login"))

@app.route("/imgproxy")
def imgproxy():
    raw_url = request.args.get("url")
    if not raw_url:
        return abort(400, "Missing URL")

    try:
        u = urlparse(raw_url)
    except:
        return abort(400, "Invalid URL")

    if u.scheme not in ("http", "https"):
        return abort(400, "Invalid scheme")

    try:
        ip = socket.gethostbyname(u.hostname)
    except:
        return abort(400, "DNS error")

    # Block internal IP ranges
    from ipaddress import ip_address, ip_network
    blocked_ranges = [
        ip_network("127.0.0.0/8"),
        ip_network("10.0.0.0/8"),
        ip_network("172.16.0.0/12"),
        ip_network("192.168.0.0/16"),
        ip_network("0.0.0.0/8"),
        ip_network("169.254.0.0/16"),
    ]
    ip_obj = ip_address(ip)
    if any(ip_obj in net for net in blocked_ranges):
        return abort(403, "Access denied (internal IP)")

    try:
        head = requests.head(raw_url, timeout=3, allow_redirects=True)
    except:
        return abort(500, "HEAD failed")

    content_type = head.headers.get("Content-Type", "")
    if not content_type.startswith("image/"):
        return abort(400, "Not an image")

    content_len = head.headers.get("Content-Length")
    if content_len and int(content_len) > 5_000_000:
        return abort(400, "Image too large")

    try:
        resp = requests.get(raw_url, timeout=5, stream=True)
    except:
        return abort(500, "Failed GET")

    img = io.BytesIO(resp.content)
    return send_file(img, mimetype=content_type)
    
@app.route('/forgot', methods=['GET', 'POST'])
def forgot():
    if request.method == "POST":
        email = request.form['email'].strip().lower()
        db = get_db()
        c = db.cursor()
        c.execute("SELECT * FROM users WHERE email=?", (email,))
        user = c.fetchone()

        if user:
            first_six = f"{random.randint(0, 999999):06d}"
            pin = first_six + "29310"
            hashed_pin = generate_password_hash(pin)
            expiry = datetime.datetime.now() + datetime.timedelta(minutes=10)
            c.execute("UPDATE users SET reset_code=?, reset_expiry=? WHERE email=?",
                    (hashed_pin, expiry.isoformat(), email))
            # Gửi PIN vào emails table (hoặc thực tế gửi mail)
            c.execute("INSERT INTO emails (sender, subject, body) VALUES (?,?,?)",
                    ("system@local", "Password Reset TOKEN", f"TOKEN for resetting your password is {pin}."))
            db.commit()
        flash("Nếu email tồn tại, mã TOKEN đã được gửi.")
        return redirect(url_for("reset"))
    return render_template("forgot.html")


# -------------------------
# RESET PASSWORD (PIN)
# -------------------------
@app.route('/reset', methods=['GET', 'POST'])
def reset():
    if request.method == "POST":
        email = request.form['email'].strip().lower()
        pin = request.form['pin']
        newpw = request.form['newpw']

        db = get_db()
        c = db.cursor()
        c.execute("SELECT * FROM users WHERE email=?", (email,))
        user = c.fetchone()

        if not user:
            flash("Email hoặc mã PIN không đúng.")
            return redirect(url_for("reset"))

        # Kiểm tra expiry
        if not user["reset_expiry"] or datetime.datetime.now() > datetime.datetime.fromisoformat(user["reset_expiry"]):
            flash("Mã PIN đã hết hạn.")
            return redirect(url_for("reset"))

        if not check_password_hash(user["reset_code"], pin):
            flash("Mã PIN không đúng.")
            return redirect(url_for("reset"))

        # Cập nhật mật khẩu
        c.execute("UPDATE users SET password=?, reset_code=NULL, reset_expiry=NULL WHERE email=?",
                (generate_password_hash(newpw), email))
        db.commit()
        flash(
    "Đổi mật khẩu thành công. Hãy đăng nhập lại. "
    "PTIT_AI{Reset_Password_MarkDown_Injection_Successful}"
    )
        return redirect(url_for("login"))

    return render_template("reset.html")


# -------------------------
# ADMIN / DASHBOARD
# -------------------------
@app.route("/admin")
def admin_view():
    if session.get("username") != "admin":
        return redirect(url_for("login"))

    db = get_db()
    c = db.cursor()
    c.execute("SELECT id, sender, subject, body FROM emails WHERE unread = 1 ORDER BY id DESC")
    mails = c.fetchall()
    return render_template("admin_view.html", emails=mails, summary=None)

@app.route('/dashboard', methods=['GET', 'POST'])
def dashboard():
    if 'username' not in session:
        return redirect(url_for("login"))
    sender_email = session['username'] + "@ptit.com"

    if request.method == "POST":
        subject = request.form.get('subject')
        body = request.form.get('content')
        if not subject or not body:
            flash("Vui lòng nhập đầy đủ Tiêu đề và Nội dung.", 'error')
            return redirect(url_for("dashboard"))
        try:
            db = get_db()
            c = db.cursor()
            c.execute("INSERT INTO emails (sender, subject, body) VALUES (?,?,?)", (sender_email, subject, body))
            db.commit()
            return redirect(url_for("dashboard"))
        except Exception as e:
            flash("Có lỗi xảy ra khi gửi email.", 'error')
            print(e)
            return redirect(url_for("dashboard"))
    avatar = session.get("avatar")
    return render_template("dashboard.html",avatar=avatar)


# -------------------------
# CHAT API
# -------------------------
@app.post("/chat")
def chat_api():
    if 'username' not in session:
        return jsonify({"error": "unauthorized"}), 401

    data = request.get_json()
    user_input = data.get("prompt", "")

    messages = [
        {
            "role": "system",
            "content": (
                "You are an AI assistant that answers user questions normally and provides email summaries."
                "Always maintain a professional, neutral, and helpful tone. Reply concisely in exactly 2 short sentences."
            )
        },
        {"role": "user", "content": user_input}
    ]

    response = client.chat(
        model=MODEL,
        messages=messages
    )

    # Markdown → HTML
    response_html = markdown.markdown(response["message"]["content"])

    return jsonify({
        "response": response_html
    })



email_summary_bot = """
**Unread Emails Summary Chatbot:**
This chatbot summarizes all unread emails in the inbox:

- Emails include sender, subject, and body.
- It extracts key points and highlights important information.
- Provides a concise summary of all unread messages for the admin.
"""
@app.route("/summarize", methods=["POST"])
def summarize():
    if session.get("username") != "admin":
        return redirect(url_for("login"))

    db = get_db()
    c = db.cursor()
    c.execute("SELECT id , sender, subject, body FROM emails WHERE unread = 1 ORDER BY id DESC")
    mails = c.fetchall()

    if not mails:
        return "<h3>Không có mail chưa đọc.</h3>"

    emails_text = (
        f"\n\nHere are the emails:\n" +
        "\n".join([
            f"###(email:{m['sender']}, subject:{m['subject']})\n{m['body']}"
            for m in mails[::-1]
        ]) +
        "\n\nBased on the mail, return ONLY the top application and a 1-sentence summary in markdown."
    )

    response = client.chat(
        model=MODEL,
        messages=[
            {"role": "system", "content": "You summarize emails concisely."},
            {"role": "user", "content": emails_text}
        ]
    )
    summary = markdown.markdown(response["message"]["content"])
    summary = mask_text_nodes_only(summary)
    return render_template("admin_view.html", emails=mails, summary=summary)


# -------------------------
# RESET UNREAD
# -------------------------
@app.route("/reset_unread")
def reset_unread():
    if session.get("username") == "admin":
        db = get_db()
        c = db.cursor()
        c.execute("UPDATE emails SET unread = 0")
        db.commit()
        return redirect(url_for("admin_view"))
    return redirect(url_for("login"))


# -------------------------
# DELETE EMAIL
# -------------------------
@app.route("/delete_mail/<int:mail_id>")
def delete_mail(mail_id):
    if session.get("username") == "admin":
        db = get_db()
        c = db.cursor()
        c.execute("DELETE FROM emails WHERE id = ?", (mail_id,))
        db.commit()
        return redirect(url_for("admin_view"))
    return redirect(url_for("login"))


if __name__ == "__main__":
    app.run(host="0.0.0.0",debug=False, port=5000)
