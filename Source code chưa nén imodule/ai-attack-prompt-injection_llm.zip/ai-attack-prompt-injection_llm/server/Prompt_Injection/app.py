from flask import Flask, render_template, request, session, redirect, url_for, flash
from flask import Flask, request, jsonify
from flask_wtf.csrf import CSRFProtect
from flask_wtf import FlaskForm 
import uuid
import ollama
import re
import yaml
import os
from summarizer import fetch_clean_text, summarize_with_ollama
from logger import request_logger, response_logger
from Defense.basic_firewall import basic_firewall
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired

class ChatForm(FlaskForm):
    message = StringField('Message', validators=[DataRequired()])
    submit = SubmitField('Send')
class LoginForm(FlaskForm):
    pass
class ResetForm(FlaskForm):
    pass

app = Flask(__name__)
@app.before_request
def log_request_info():
    request_logger.info("----- REQUEST -----")
    request_logger.info(f"Path: {request.path}")
    request_logger.info(f"Method: {request.method}")
    request_logger.info(f"Remote Addr: {request.remote_addr}")

    if request.method != "GET":
        request_logger.info(f"Body: {request.get_data(as_text=True)}")

@app.after_request
def log_response_info(response):
    response_logger.info("----- RESPONSE -----")
    response_logger.info(f"Status: {response.status}")
    try:
        response_logger.info(f"Response Body: {response.get_data(as_text=True)}")
    except:
        response_logger.info("Response Body: <unreadable>")
    return response
client=ollama.Client("http://192.167.2.4:29310")
MODEL = "llama3.1:8b"
app.secret_key = os.environ.get('SECRET_KEY', str(uuid.uuid4()))
app.config['WTF_CSRF_ENABLED'] = True 
csrf = CSRFProtect(app)
CONFIG_PATH = "config.yaml"
if not os.path.exists(CONFIG_PATH):
    raise RuntimeError(f"Missing {CONFIG_PATH} - create it based on the example provided.")

with open(CONFIG_PATH, "r",encoding="utf-8") as f:
    config = yaml.safe_load(f)

levels = config.get("levels", [])
flag = config.get("flag", [])
sessions = {}

TURN_LIMIT = 3

def get_level(level_id):
    return next((lvl for lvl in levels if lvl["id"] == level_id), None)

def store_message(user_id, role, content):
    if user_id not in sessions:
        sessions[user_id] = []
    sessions[user_id].append({"role": role, "content": content})


def call_ollama(user_id):
    history = sessions.get(user_id, [])
    response = client.chat(
        model=MODEL,
        messages=history,
    )
    return response['message']['content']

def mask_secrets(response):
    response = re.sub(r'PTIT_AI\{.*?\}', lambda m: 'PTIT_AI{' + '*'*(len(m.group(0))-8) + '}', response)
    return response

@app.route('/')
def index():
    login_form = LoginForm() 
    return render_template('index.html', levels=levels, login_form=login_form)

@app.route('/login', methods=['POST'])
def login():

    level_id_raw = request.form.get('level')
        
    try:
        level_id = int(level_id_raw)
    except (TypeError, ValueError):
        flash("Invalid level selected", "error")
        return redirect(url_for('index'))

    level = get_level(level_id)
    if not level:
        flash("Invalid level selected", "error")
        return redirect(url_for('index'))

    user_id = str(uuid.uuid4())
    session['user_id'] = user_id
    session['role'] = "Ptiter"
    session['level_id'] = level_id

    role = session.get('role')
    store_message(user_id, "system", level["system_prompt"])

    return redirect(url_for('chat'))

@app.route('/chat', methods=['GET', 'POST'])
def chat():
    user_id = session.get('user_id')
    level_id = session.get('level_id')
    
    if not user_id or not level_id:
        return redirect(url_for('index'))
    level= get_level(level_id)
    if level_id == 5 :
        return redirect(url_for('summarize_web'))
    elif level_id==6 :
        return redirect(url_for('basic_firewall_chat'))

    
    chat_form = ChatForm()
    reset_form = ResetForm()
    
    if request.method == 'POST':
        if chat_form.validate_on_submit(): 
            user_input = request.form.get('message', '')
            turns = session.get('turns', 0) + 1
            session['turns'] = turns
            if turns > TURN_LIMIT:
                session['turns'] = 0
                username = session.get('username', 'Unknown')
                role = session.get('role', 'user')
                level_id = session.get('level_id')
                level = get_level(level_id)

                sessions[user_id] = [
                    {"role": "system", "content": level["system_prompt"]},
                ]
                
                flash("Chat was automatically reset after 3 turns.", "info")
                return redirect(url_for('chat'))
        
            store_message(user_id, "user", user_input)

            bot_response = call_ollama(user_id)
            
        if session['level_id']==3 :
            bot_response = mask_secrets(bot_response)
        elif (session['level_id']==4) :
            if bot_response not in ["granted", "denied"]:
                bot_response = "denied"
            elif bot_response =="granted":
                bot_response += " Here is the flag: PTIT_AI{Prompt_Injection_Granted}"
        store_message(user_id, "assistant", bot_response)
        
    chat_history_original = sessions.get(user_id, [])
    

    return render_template(
        'chat.html', 
        chat_history=chat_history_original, 
        level=level, 
        chat_form=chat_form, 
        reset_form=reset_form 
    )

@app.route('/basic_firewall_chat', methods=['GET', 'POST'])
def basic_firewall_chat():
    user_id = session.get('user_id')
    level_id = session.get('level_id')

    # Chỉ cho Level 6
    if not user_id or level_id != 6:
        flash("❌ Chức năng này chỉ dùng cho Level 6!", "error")
        return redirect(url_for('chat'))

    chat_form = ChatForm()
    reset_form = ResetForm()
    chat_history = sessions.get(user_id, [])

    if request.method == 'POST' and chat_form.validate_on_submit():
        user_input = chat_form.message.data.strip()  

        if not basic_firewall.is_allowed(user_input, "input"):
            flash(basic_firewall.get_rejection_message("input"), "error")
            return redirect(url_for('basic_firewall_chat'))

        store_message(user_id, "user", user_input)

        bot_response = call_ollama(user_id)

        if not basic_firewall.is_allowed(bot_response, "output"):
            bot_response = basic_firewall.get_rejection_message("output")

        store_message(user_id, "assistant", bot_response)

        chat_history = sessions.get(user_id, [])

    return render_template(
        'chat.html',
        chat_history=chat_history,
        level=get_level(level_id),
        chat_form=chat_form,
        reset_form=reset_form
    )

@app.route('/hint_level_6')
def hint_level_6():
    user_id = session.get('user_id')
    level_id = session.get('level_id')
    if not user_id or level_id != 6:
        flash("❌ Gợi ý này chỉ dành cho Level 6.", "error")
        return redirect(url_for('chat'))

    firewall_file_path = os.path.join(app.root_path, 'Defense', 'basic_firewall.py')
    file_content = ""
    try:
        with open(os.path.join('Defense', 'basic_firewall.py'), 'r', encoding='utf-8') as f:
            file_content = f.read()
    except FileNotFoundError:
        file_content = "Lỗi: Không tìm thấy file tường lửa . Vui lòng kiểm tra đường dẫn."


    
    return render_template('hint.html', 
                        file_content=file_content, 
                        level=get_level(level_id))

@app.route("/summarize_web", methods=["GET"])
def summarize_web_page():
    user_id = session.get("user_id")
    level_id = session.get("level_id")
    if not user_id or level_id != 5:
        flash("❌ Chức năng Summarizer chỉ được sử dụng ở Level 5!", "error")
        return redirect(url_for("chat"))
    return render_template("summary.html")

@csrf.exempt
@app.route("/summarize_web", methods=["POST"])
def summarize_web():

    user_id = session.get("user_id")
    level_id = session.get("level_id")

    if not user_id or level_id != 5:
        return jsonify({"error": "Summarizer chỉ dùng cho Level 6"}), 403

    data = request.get_json()
    if not data or "url" not in data:
        return jsonify({"error": "URL missing"}), 400

    url = data["url"]

    if not (url.startswith("http://") or url.startswith("https://")):
        return jsonify({"error": "URL không hợp lệ"}), 400
    try:
        text = fetch_clean_text(url)
        summary = summarize_with_ollama(text)
        return jsonify({"summary": summary})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

# Reset chat
@app.route('/reset_chat', methods=['POST'])
def reset_chat():
    reset_form = ResetForm()
    
    if reset_form.validate_on_submit():
        user_id = session.get('user_id')
        level_id = session.get('level_id')
        username = session.get('username', 'Unknown')
        role = session.get('role', 'user')

        if user_id and level_id:
            level = get_level(level_id)
            if level:
                sessions[user_id] = [
                    {"role": "system", "content": level["system_prompt"]}
                ]
        flash("Chat history has been reset.", "info")
    
    return redirect(url_for('chat'))


# Đăng xuất
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(host="0.0.0.0", port=5000, debug=False)
