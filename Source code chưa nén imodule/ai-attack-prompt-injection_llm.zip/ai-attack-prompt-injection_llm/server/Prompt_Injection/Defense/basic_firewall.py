import re
import random
import nltk
from typing import Callable, List

nltk.download('punkt', quiet=True)
from nltk.tokenize import sent_tokenize


class PromptFirewall:

    def __init__(self):

        # ============================================================
        # 🔥 INPUT RULES
        # ============================================================
        self.input_rules: List[Callable[[str], bool]] = [

            # ======================
            # 1. SYSTEM OVERRIDE
            # ======================
            self.rex(r"(ignore|bypass|override|disregard|forget|reset).*(system|prompt|rule|instruction)"),
            self.rex(r"(break|escape).*(role|jail|limit|constraint)"),
            self.rex(r"jailbreak|uncensored|raw mode|developer mode"),
            self.rex(r"(you are now|act as|pretend to|simulate|from now on)"),
            self.rex(r"(new|temporary|alternate) system prompt"),

            # ======================
            # 2. PROMPT EXTRACTION / LEAK
            # ======================
            self.rex(r"(show|reveal|tell|display|print).*(prompt|instruction|system message|internal)"),
            self.rex(r"(what is|give).*(your|the).*(prompt|rules|setup|config|check)"),
            self.rex(r"meta prompt|inner prompt|developer prompt"),
            self.rex(r"\b(\w+\s+)?key\b|\b(token|secret)\b"),

            # ======================
            # 3. ENCODING-BASED JAILBREAKS
            # ======================
            self.rex(r"(encode|decode|convert|respond|reply).*(base64|hex|base32|rot13|binary)"),
            self.rex(r"(encrypt|decrypt).*(text|message|instruction)"),

            # ======================
            # 4. LOGIC JAILBREAKS – REVERSE PSYCHOLOGY
            # ======================
            self.rex(r"(ignore the previous instructions|regardless of rule|do the opposite)"),
            self.rex(r"(i allow you|you have permission to|you are authorized)"),
            self.rex(r"(this is a harmless test|for research purposes|this is safe)"),

            # ======================
            # 5. SOCIAL ENGINEERING OVERRIDE
            # ======================
            self.rex(r"i('m| am) (admin|administrator|developer|dev|creator|owner)"),
            self.rex(r"(i have|i am).*(authorization|permission|access)"),
            self.rex(r"(trust me|i promise|no harm)"),

            # ======================
            # 6. ATTACK PAYLOADS / CODE EXEC
            # ======================
            self.rex(r"[`]{1,3}.*[`]{1,3}"),
            self.rex(r"\$\(.+\)"),
            self.rex(r"(;|&&|\|\|).+"),
            self.rex(r"eval\(|exec\("),
            self.rex(r"import os|import subprocess|from os"),

            # ======================
            # 7. HTML / MARKDOWN INJECTION
            # ======================
            self.rex(r"\!\[.*?\]\(.*?\)"),
            self.rex(r"<img.*?>"),
            self.rex(r"<script.*?>"),
            self.rex(r"<style.*?>"),
            self.rex(r"<iframe.*?>"),
            self.rex(r"<a .*href=.*>"),

            # ======================
            # 8. GAME SECRETS / FLAGS
            # ======================
            self.rex(r"(flag|secret|token|credential|api key|password)"),
            self.rex(r"ptit[_ ]?ai"),

            # ======================
            # 9. OUTPUT CONTROL MANIPULATION
            # ======================
            self.rex(r"(only respond|reply only|output only|respond exclusively)"),
            self.rex(r"(speak in|answer in|write in).*(json|yaml|xml|base64|hex)"),

            # ======================
            # 10. OBFUSCATION JAILBREAK (unicode, homoglyphs)
            # ======================
            self.rex(r"[^\x00-\x7F]{3,}"),  # non‑ASCII injections
            self.rex(r"[\u202E\u202A\u202B\u202D\u202C]"),  # bidi override

            # ======================
            # 11. CONVERSATIONAL TRICKS
            # ======================
            self.rex(r"(hypothetically|imagine|what if).*(you break rules)"),
            self.rex(r"(let's play a game|new persona|new identity)"),
            self.rex(r"(roleplay|rp as|in character as)"),
        ]

        # ============================================================
        # 🔥 OUTPUT RULES
        # ============================================================
        self.output_rules: List[Callable[[str], bool]] = [

            # ----- Flag leakage -----
            self.rex(r"PTIT_AI\{.*?\}"),
            self.rex(r"\{.*?\}IA_TITP"),

            # ----- Encoded output -----
            self.rex(r"[A-Za-z0-9+/]{20,}={0,2}"),   # Base64 long
            self.rex(r"[A-Fa-f0-9]{25,}"),           # long hex
            self.rex(r"[01]{30,}"),                  # binary stream

            # ----- System meta exposure -----
            self.rex(r"(system prompt|developer note|internal rule|tool list|tools available)"),

            # ----- Markdown / HTML -----
            self.rex(r"\!\[.*?\]\(.*?\)"),
            self.rex(r"<img.*?>"),
            self.rex(r"<script.*?>"),

            # ----- Dangerous output pattern -----
            self.rex(r"[`]{1,3}.*[`]{1,3}"),
            self.rex(r"\$\(.+\)"),
            self.rex(r"(;|&&|\|\|).+"),

            # ----- Unusually structured responses -----
            self.rex(r"^\s*(json|yaml|xml)\s*\{", re.I),
            self.rex(r"^\s*\{.*?\:\s*.*?\}", re.I),
        ]

    # ============================================================
    # BASIC CHECK
    # ============================================================
    def is_allowed(self, message: str, direction: str) -> bool:
        rules = self.input_rules if direction == "input" else self.output_rules
        return not any(rule(message) for rule in rules)

    # ============================================================
    # REGEX MATCHER
    # ============================================================
    def rex(self, pattern: str, flags=re.IGNORECASE):
        compiled = re.compile(pattern, flags)
        return lambda text: bool(compiled.search(text))

    # ============================================================
    # REJECTION MESSAGE
    # ============================================================
    def get_rejection_message(self, direction: str) -> str:
        inputs = [
            "❌ Input bị chặn: yêu cầu vi phạm quy tắc an toàn.",
            "🚫 Không thể xử lý yêu cầu này.",
            "⚠️ Yêu cầu bị từ chối vì nội dung không hợp lệ.",
        ]
        outputs = [
            "❌ Đầu ra đã bị chặn vì chứa nội dung nguy hiểm.",
            "⚠️ Không thể hiển thị phản hồi này.",
            "🚫 Phản hồi bị từ chối do vi phạm chính sách an toàn.",
        ]
        return random.choice(inputs if direction == "input" else outputs)


# Export
basic_firewall = PromptFirewall()
