import csv
from VulnerableBot import VulnerableBot

input_file = "prompts.csv"
output_file = "results.csv"

bot = VulnerableBot()

with open(input_file, "r", encoding="utf-8") as f_in, \
     open(output_file, "w", newline="", encoding="utf-8") as f_out:

    reader = csv.DictReader(f_in)
    fieldnames = ["id", "technique", "prompt", "response"]

    writer = csv.DictWriter(f_out, fieldnames=fieldnames)
    writer.writeheader()

    for row in reader:
        print(f"Processing ID {row['id']}...")

        user_prompt = row["prompt"]
        bot_reply = bot.ask(user_prompt)

        writer.writerow({
            "id": row["id"],
            "technique": row["technique"],
            "prompt": user_prompt,
            "response": bot_reply.replace("\n", " ")
        })

print("✔ File results.csv da san sang")
