from flask import Flask, request, jsonify
import requests
import os

app = Flask(__name__)

OLLAMA_HOST ="https://postosseous-superjudicially-shavon.ngrok-free.dev/"

@app.route("/api/chat", methods=["POST"]) 
def proxy_chat():
    """
    Forward request từ Flask server tới Ollama thật qua Ngrok.
    """
    try:
        data = request.get_json()
        resp = requests.post(f"{OLLAMA_HOST}/api/chat", json=data, timeout=60)
        resp.raise_for_status() 
        
        return jsonify(resp.json())
    except requests.exceptions.RequestException as e:
        print(f"Lỗi khi forward request: {e}")
        return jsonify({"error": f"Lỗi kết nối đến Ollama qua Ngrok: {str(e)}"}), 503
    except Exception as e:
        return jsonify({"error": f"Lỗi nội bộ Proxy: {str(e)}"}), 500

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=29310)
