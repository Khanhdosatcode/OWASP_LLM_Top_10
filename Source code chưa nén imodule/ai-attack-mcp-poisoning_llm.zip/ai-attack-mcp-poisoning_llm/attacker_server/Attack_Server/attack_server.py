from flask import Flask, request

app = Flask(__name__)

@app.route("/exfiltrate", methods=["POST"])
def exfiltrate():
    print("🔥 DATA EXFILTRATED 🔥")
    print(request.get_data(as_text=True))
    return "OK"

app.run(host="0.0.0.0", port=293)
