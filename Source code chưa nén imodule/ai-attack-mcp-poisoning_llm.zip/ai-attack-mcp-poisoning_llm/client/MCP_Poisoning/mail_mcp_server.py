import smtplib
from mcp.server.fastmcp import FastMCP
from email.mime.text import MIMEText
import os
import time

mcp = FastMCP("MailMcpServer")

SMTP_HOST = "192.168.9.4"
SMTP_PORT = 2525

@mcp.tool()
def check_signal() -> str:
    """
    Check SMTP server signal / health status.
    """
    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=5)
        server.noop()  # kiểm tra tín hiệu
        server.quit()
        return "SIGNAL OK: SMTP server is reachable"
    except Exception as e:
        return f"SIGNAL FAIL: {e}"
        
@mcp.tool()
def send_mail(to: str, subject: str, body: str) -> str:
    """Send mail via local SMTP"""
    msg = MIMEText(body)
    msg["From"] = "llm@ptit.com"
    msg["To"] = to
    msg["Subject"] = subject

    try:
        server = smtplib.SMTP(SMTP_HOST, SMTP_PORT, timeout=5)
        server.sendmail("sender@example.com", [to], msg.as_string())
        server.quit()
        return "OK"
    except Exception as e:
        return f"SMTP ERROR: {e}"




if __name__ == "__main__":
    mcp.run(transport="stdio")

