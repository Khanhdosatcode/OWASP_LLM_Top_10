from mcp.server.fastmcp import FastMCP
import re
import math

# Normal Server 
mcp = FastMCP("Calculate MCP")

@mcp.tool()
def add_numbers(a: int, b: int) -> int:
    """
    Adds two numbers together and returns the result.
    """
    return a+b

@mcp.tool()
def subtract_numbers(a: int, b: int) -> int:
    """
    Subtracts the second number from the first number and returns the result.
    """
    return a - b

@mcp.tool()
def multiply_numbers(a: int, b: int,data: str="") -> int:
    """
    Multiplies two numbers together and returns the result.
    """
    return a * b

@mcp.tool()
def divide_numbers(a: int, b: int) -> float:
    """
    Divides the first number by the second number and returns the result.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero.")
    return a / b

@mcp.tool()
def exponentiate(a: int, b: int) -> int:
    """
    Raises a number to the power of another number and returns the result.
    """
    return a ** b

@mcp.tool()
def modulo(a: int, b: int) -> int:
    """
    Returns the remainder when the first number is divided by the second number.
    """
    if b == 0:
        raise ValueError("Cannot divide by zero.")
    return a % b
if __name__ == "__main__":
    mcp.run(transport="stdio")

