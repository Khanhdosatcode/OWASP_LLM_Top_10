import threading
import time
from aiosmtpd.controller import Controller
from email.parser import BytesParser
from email.message import Message
from flask import Flask, render_template_string, request, redirect, url_for
from logger import request_logger, response_logger
import logging

# --- Inbox storage ---
inbox = []

# --- Hàm chia nhỏ dòng dài ---
def split_long_lines(text, max_length=1000):
    lines = text.split("\n")
    result = []
    for line in lines:
        while len(line) > max_length:
            result.append(line[:max_length])
            line = line[max_length:]
        result.append(line)
    return "\n".join(result)

# --- SMTP Handler ---
class Handler:
    async def handle_DATA(self, server, session, envelope):
        try:
            msg: Message = BytesParser().parsebytes(envelope.content)
            sender = envelope.mail_from
            recipients = envelope.rcpt_tos
            subject = msg.get("Subject", "(No Subject)")

            # --- Handle multipart and bytes payload ---
            body = ""
            if msg.is_multipart():
                for part in msg.walk():
                    if part.get_content_type() == "text/plain":
                        payload = part.get_payload(decode=True)
                        if payload:
                            body += payload.decode(errors="ignore")
            else:
                payload = msg.get_payload(decode=True)
                if payload:
                    body = payload.decode(errors="ignore")
                else:
                    body = str(msg.get_payload())

            # --- Chia nhỏ các dòng nếu cần ---
            body = split_long_lines(body)

            # --- Lưu email vào inbox ---
            inbox.append({
                "from": sender,
                "to": recipients,
                "subject": subject,
                "body": body
            })

            print(f"\n📩 Email received:")
            print(f"From: {sender}")
            print(f"To: {recipients}")
            print(f"Subject: {subject}")
            print(f"Body:\n{body}")

            return "250 OK"
        except Exception as e:
            print("❌ SMTP error:", e)
            return "250 OK"

# --- Start SMTP server in background thread ---
def start_smtp():
    controller = Controller(Handler(), hostname="0.0.0.0", port=2525)
    controller.start()
    print("🚀 SMTP Server running at 0.0.0.0:2525")
    while True:
        time.sleep(1)

threading.Thread(target=start_smtp, daemon=True).start()

# --- Flask Web App ---
app = Flask(__name__)

@app.before_request
def log_request_info():
    try:
        request_logger.info("----- REQUEST -----")
        request_logger.info(f"Path: {request.path}")
        request_logger.info(f"Method: {request.method}")
        request_logger.info(f"Remote Addr: {request.remote_addr}")
        if request.method != "GET":
            request_logger.info(f"Body: {request.get_data(as_text=True)}")
    except Exception as e:
        request_logger.warning(f"Request logging failed: {e}")

@app.after_request
def log_response_info(response):
    try:
        response_logger.info("----- RESPONSE -----")
        response_logger.info(f"Status: {response.status}")
        response_logger.info(f"Response Body: {response.get_data(as_text=True)}")
    except Exception as e:
        response_logger.warning(f"Response logging failed: {e}")
    return response

# --- HTML Template ---
HTML = """
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>📥 Hộp Thư </title>
    <style>
        body { font-family: Arial; background: #f2f2f2; padding: 20px; }
        .card { background: white; padding: 15px; border-radius: 8px;
                margin-bottom: 20px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        pre { background: #f7f7f7; padding: 10px; border-radius: 6px; }
        button { padding: 8px 16px; margin-top: 10px; background-color: red; color: white; border: none; border-radius: 5px; cursor: pointer; }
    </style>
</head>
<body>
<h1>📥 Hộp Thư</h1>

{% if inbox %}
    {% for email in inbox %}
        <div class="card">
            <h2>{{ email.subject }}</h2>
            <b>Người gửi:</b> {{ email.from }}<br>
            <b>Người nhận:</b> {{ email.to }}<br><br>
            <pre>{{ email.body }}</pre>
            <form action="/delete/{{ loop.index0 }}" method="POST">
                <button type="submit">Xóa</button>
            </form>
        </div>
    {% endfor %}
{% else %}
    <p>Chưa có email nào được nhận.</p>
{% endif %}

</body>
</html>
"""

@app.get("/")
def index():
    return render_template_string(HTML, inbox=inbox)

@app.post("/delete/<int:email_id>")
def delete_email(email_id):
    inbox.pop(email_id, None)
    return redirect(url_for('index'))

# --- Run Flask ---
if __name__ == "__main__":
    print("🌐 Web UI at: http://127.0.0.1:5000")
    app.run(host="0.0.0.0", port=5000, debug=False, use_reloader=False)

